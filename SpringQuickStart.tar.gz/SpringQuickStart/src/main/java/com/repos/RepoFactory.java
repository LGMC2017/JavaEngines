package com.repos;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class RepoFactory {
	private static ClassPathXmlApplicationContext context;
	
	public static IRepository getBean(String beanName) {
		context = new ClassPathXmlApplicationContext("applicationContext.xml");
		IRepository repo = (IRepository) context.getBean(beanName);
		return repo;
	}
	
	public static IRepository getRepo(String reponame) {
		switch (reponame) {
		case "PlayerRepository":
			return new PlayerRepository();
		default:
			return null;
		}
	}

}
