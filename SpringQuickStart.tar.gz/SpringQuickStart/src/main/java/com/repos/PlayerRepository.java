package com.repos;


import java.util.ArrayList;
import java.util.List;

import com.models.BaseEntity;
import com.models.Player;
import com.repos.IRepository;

public class PlayerRepository implements IRepository {

	private final static int NUMITEMS = 10;
	private ArrayList<BaseEntity> listofitems;
	
	public List<BaseEntity> getAll() {
		if(listofitems == null) {
			listofitems = new ArrayList<BaseEntity>();
			for(int i = 0; i < NUMITEMS; i++) {
				Player p = new Player();
				p.setName("Player" + i);
				listofitems.add(p);
			}
		}
		return listofitems;
	}
	
	public void save(BaseEntity item) {
			if(item != null) {
			listofitems.add(item);
		}
	}

}
