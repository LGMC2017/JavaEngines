package com.repos;

import java.util.List;

import com.models.BaseEntity;

public interface IRepository {

	public List<BaseEntity> getAll();
	public void save(BaseEntity item);
	
}
