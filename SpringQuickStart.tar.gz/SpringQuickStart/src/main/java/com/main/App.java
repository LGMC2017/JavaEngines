package com.main;

import javax.swing.JDialog;
import javax.swing.JFrame;
import com.gui.MainFrame;
import com.repos.PlayerRepository;
import com.repos.RepoFactory;

public class App 
{
    public static void main( String[] args )
    {
    	JFrame.setDefaultLookAndFeelDecorated(true);
    	JDialog.setDefaultLookAndFeelDecorated(true);   
    	
    	PlayerRepository repo = (PlayerRepository) RepoFactory.getBean("PlayerRepository");
    	
    	MainFrame mframe = new MainFrame(repo);
    	mframe.setVisible(true);
    	
    }
}
