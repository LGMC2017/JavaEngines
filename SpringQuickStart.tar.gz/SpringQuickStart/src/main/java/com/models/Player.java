package com.models;

public class Player extends BaseEntity {

}
