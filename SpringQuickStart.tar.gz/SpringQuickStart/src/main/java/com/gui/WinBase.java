package com.gui;

import javax.swing.JFrame;

public abstract class WinBase extends JFrame {

	private static final long serialVersionUID = 1L;
	private static final int WINWIDTH = 500;
	private static final int WINHEIGHT = 350;
	
	protected WinBase() {
		super();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(WINWIDTH, WINHEIGHT);
		setLocationRelativeTo(null);
	} 

}
