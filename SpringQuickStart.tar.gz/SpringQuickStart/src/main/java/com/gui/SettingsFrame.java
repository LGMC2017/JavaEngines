package com.gui;

import javax.swing.JFrame;

public class SettingsFrame extends WinBase {

	private static final long serialVersionUID = 1L;
	private static final int WINWIDTH = 200;
	private static final int WINHEIGHT = 200;
	
	public SettingsFrame() {
		super();
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setSize(WINWIDTH, WINHEIGHT);
		setLocationRelativeTo(this.getParent());
	}
	
}
