package com.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

import com.models.BaseEntity;
import com.repos.IRepository;

public class MainFrame extends WinBase {

	private static final long serialVersionUID = 1L;
	private final IRepository repository;
	
	private JMenuBar mbar;
	private JMenu mmenu;
	private JList<String> itemlist;
	private SettingsFrame setFrame;
	
	public MainFrame(IRepository repo) {
		super();
		repository = repo;
		initGui();
	}
	
	private void initGui() {
		
		// * MENU
		mbar = new JMenuBar();				
		mmenu = new JMenu("File");		
		mmenu.add(new JMenuItem("Open"));
		mmenu.add(new JMenuItem("Config"));	
		mmenu.add(new JSeparator());
		mmenu.add(new JMenuItem("Exit"));
		mbar.add(mmenu);
		setJMenuBar(mbar);	
		
		// * LIST
		itemlist = new JList<String>();
		itemlist.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10, 10, 10), new EtchedBorder()));
		DefaultListModel<String> dmodel = new DefaultListModel<String>();
		itemlist.setModel(dmodel);		
		for(BaseEntity be : repository.getAll()) 
		{
			dmodel.addElement(be.getName());
		}
		getContentPane().add(itemlist);
		
		// * EVENTS
		initEvents();
	}
	
	private void initEvents() {
		
		int smenus = mmenu.getItemCount();
		for(int i = 0; i < smenus; i++)
		{
			JMenuItem mitem = mmenu.getItem(i);
			if(mitem instanceof JMenuItem) {
				JMenuItem menuitem = (JMenuItem) mitem;
				menuitem.addActionListener(new ActionListener() {					
				public void actionPerformed(ActionEvent e) {
					switch(e.getActionCommand()) 
					{
						case "Exit": 
							if(JOptionPane.showConfirmDialog(MainFrame.this, "Are you sure?", "Close Application", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION)
							{
								MainFrame.this.setVisible(false);
								System.exit(0);
							}
							return;
						case "Open": 
							JFileChooser fchooser = new JFileChooser();
							fchooser.showOpenDialog(MainFrame.this);
							return;
						case "Config":
							if(setFrame == null) {
								setFrame = new SettingsFrame();
							}
							setFrame.setVisible(true);
							return;
						default:
							return;
					}
				}
				});
			}
		}
	}

}
