package com.main;

import com.ui.MainWin;

public class Program {

	public static void main(String[] args) {
		try {
			//UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
			javax.swing.JFrame.setDefaultLookAndFeelDecorated(true);
			javax.swing.JDialog.setDefaultLookAndFeelDecorated(true);
			MainWin win = new MainWin();
			win.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
