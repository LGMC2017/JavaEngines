package com.ui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import com.requester.HttpRequester;

@SuppressWarnings("unused")
public class MainWin extends JFrame {	

	private static final long serialVersionUID = 1L;
	private static final int WWIDTH = 175;
	private static final int WHEIGHT = 100;	
	private JPanel p1 = new JPanel();
	private JButton b1 = new JButton("Call");
	private Connection con;
	private HttpRequester httpreq;
	
	public MainWin() {
		super();
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(WWIDTH,WHEIGHT);
		setLocationRelativeTo(null);
		initComponents();
	}
	
	private void initComponents() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gabodb?user=root&password=dev123&useSSL=false");			
		} catch (SQLException | ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
		this.setLayout(new BorderLayout());
		p1.add(b1);
		getContentPane().add(p1, BorderLayout.SOUTH);
		b1.addActionListener(new ActionListener() {			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					//testConnection();
					httpreq = new HttpRequester();
					httpreq.makeSimpleRequest("http://localhost:8080/WARJul10/ServiceServlet", "GET");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
	}
	
	private void testConnection() throws SQLException {
		Statement stm = con.createStatement();			
		ResultSet rs = stm.executeQuery("SELECT * FROM logins");
		while(rs.next()) {				
			System.out.println(rs.getString("logname"));
		}	
		rs.close();
		stm.close();
	}

}
