package com.ejbs;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;

import com.models.MessageEntry;

/**
 * Session Bean implementation class ServiceBean
 */
@Stateless
public class ServiceBean implements ServiceBeanLocal {

    public ServiceBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String getMessage(int messageid) {
		
		return "Message Response";
	}

	@Override
	public List<String> getAllMessages() {
		List<String> items = new ArrayList<String>();
		for(int i = 0; i < 100; i++) {
			items.add("Item"+i);
		}
		return items;
	}

	@Override
	public MessageEntry getCustomMessage() {
		MessageEntry entry = new MessageEntry();
		entry.setId(100324);
		entry.setMessage("This message was created from the EJB");
		return entry;
	}

}
