package com.ejbs;

import java.util.List;

import javax.ejb.Local;

import com.models.MessageEntry;

@Local
public interface ServiceBeanLocal {
	
	public String getMessage(int messageid);
	public List<String> getAllMessages();
	public MessageEntry getCustomMessage();

}
