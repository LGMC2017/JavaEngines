package com.servlets;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ejbs.ServiceBeanLocal;
import com.models.MessageEntry;

@WebServlet("/ServiceServlet")
public class ServiceServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	@EJB private ServiceBeanLocal bean; 
	
    public ServiceServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		List<String> messages = bean.getAllMessages();
		MessageEntry entry = bean.getCustomMessage();
		
		//response.getWriter().println("BEAN: " + entry.getId() + " says " + entry.getMessage());
		//response.getWriter().close();
		
		ServletOutputStream stream = response.getOutputStream();
		BufferedOutputStream buffer = new BufferedOutputStream(stream);
		for(String s : messages) {		
			buffer.write(s.getBytes());
			buffer.flush();
		}
		stream.close();
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
