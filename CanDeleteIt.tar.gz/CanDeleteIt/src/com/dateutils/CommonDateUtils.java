package com.dateutils;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class CommonDateUtils {
	
	public  static final int TOTALMONTHS = 12;	
	
	public static int[] daysofmonths(Calendar cal) 
	{
		int[] months = new int[] {0,1,2,3,4,5,6,7,8,9,10,11};
		int[] daysinmonth = new int[TOTALMONTHS];
		
		for(int month = 0; month < TOTALMONTHS;  month++) 
		{
			cal.set(Calendar.MONTH, month);
			daysinmonth[month] = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		}
		
		return daysinmonth;
	}
	
	public static int[] daysofmonths(int year) 
	{
		Calendar cal = new GregorianCalendar();
		cal.set(Calendar.YEAR, year);
		return daysofmonths(cal);
	}
	
	public static int getLastDay(int month, int year) 
	{
		return daysofmonths(year)[month-1];
	}
}
