package com.levels;

public class PlayerLevel {
		
	public enum Level {
		
		LEVEL1(1, 0, 749.99, 1.00),
		LEVEL2(2, 750, 2999.99, 1.50), 
		LEVEL3(3, 3000, 7499.99, 2.00), 
		LEVEL4(4, 7500, 99999.99, 2.50), 
		LEVEL5(5, 100000, 999999.99, 3.50), 
		LEVEL6(6, 1000000, Double.MAX_VALUE, 5.00);
		
		private final int numlevel;
		private final double minpoints;
		private final double maxpoints;
		private final double fppratio;
		
		private Level(int _numlevel, double _min, double _max, double _fppratio) 
		{			
			this.numlevel = _numlevel;
			this.minpoints = _min;
			this.maxpoints = _max;
			this.fppratio = _fppratio;
		}

		public int getLevelNumber() {
			return numlevel;
		}

		public double getMinLevelPoints() {
			return minpoints;
		}

		public double getMaxLevelPoints() {
			return maxpoints;
		}
		
		public double getFPPRatio() {
			return this.fppratio;
		}
		
		public Level nextLevel() {
			Level[] levels = Level.values();
			int nextindex = this.ordinal()+1;
			return (nextindex < levels.length)? levels[nextindex] : getLevel(Double.MAX_VALUE);
		}
		
		public Level previousLevel() {
			Level[] levels = Level.values();
			int previndex = this.ordinal()-1;
			return (previndex > 0)? levels[previndex] : getLevel(Double.MIN_VALUE);
		}
		
	};
	
	public static Level getLevel(double points) {
		Level level = Level.LEVEL1;
		for(Level l : Level.values()) 
		{
			if(points >= l.minpoints && points <= l.maxpoints) {
				level = l;	
				break;
			}
		}
		return level;
	}

}
