package com.levels;

import com.levels.PlayerLevel.Level;

public class Player {
	
	private static final double STATUSPOINTS_AWARD = 5.5;
	
	private Level playerLevel;
	private String userName;
	private boolean isVip;
	private double statusPoints;
	private int defenseMonth;
	private double rake;
	
	private double frequentPoints = 0.0;	
	private double monthlypoints = 0.0;
	private double yearlypoints = 0.0;
	
	public Player() {
		this.playerLevel = PlayerLevel.Level.LEVEL1;
		this.userName = new String();
		this.isVip = false;
		this.statusPoints = 0;
		this.defenseMonth = 0;
		this.rake = 0.0;
	}
	
	public Player(Level playerLevel, String userName, boolean isVip, double statusPoints, int defenseMonth,
			double rake) {
		this.playerLevel = playerLevel;
		this.userName = userName;
		this.isVip = isVip;
		this.statusPoints = statusPoints;
		this.defenseMonth = defenseMonth;
		this.rake = rake;
		this.frequentPoints = this.playerLevel.getFPPRatio() * statusPoints;
	}
	
	public double addRake(double newrake) 
	{
		this.rake = newrake;
		playerCalculatePoints();
		return this.rake;
	}
	
	/// This method keeps the logic for calculate statuspoint & level
	public void playerCalculatePoints() 
	{
		Level currentlevel = this.playerLevel;
		
		this.statusPoints = this.rake * STATUSPOINTS_AWARD;
		
		this.monthlypoints += this.statusPoints;
		
		this.yearlypoints += this.statusPoints;
		
		Level newlevel = PlayerLevel.getLevel(this.monthlypoints);
		
		this.frequentPoints += (this.playerLevel.getFPPRatio() * this.statusPoints) - this.frequentPoints;
		
		if(currentlevel.getLevelNumber() < newlevel.getLevelNumber()) {
			System.out.print("*");
			this.playerLevel = newlevel;
			this.isVip = this.playerLevel.getLevelNumber() >= Level.LEVEL5.getLevelNumber();
		}
	}
	
	public Level getPlayerLevel() {
		return playerLevel;
	}
	
	public void setPlayerLevel(Level playerLevel) {
		this.playerLevel = playerLevel;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public boolean isVip() {
		return isVip;
	}
	
	public void setVip(boolean isVip) {
		this.isVip = isVip;
	}
	
	public double getStatusPoints() {
		return statusPoints;
	}
	
	public void setStatusPoints(double statusPoints) {
		this.statusPoints = statusPoints;
	}
	
	public int getDefenseMonth() {
		return defenseMonth;
	}
	
	public void setDefenseMonth(int defenseMonth) {
		this.defenseMonth = defenseMonth;
	}	
	
	public double getRake() {
		return rake;
	}
	
	protected void setRake(double rake) {
		this.rake = rake;
	}
	
	public double getYearlyPoints() {
		return yearlypoints;
	}
	
	public double getMonthlyPoints() {
		return monthlypoints;
	}
	
	public double getFrequentPoints() {
		return this.frequentPoints;
	}

	@Override
	public String toString() {
		return "Player [playerLevel=" + playerLevel + ", isVip=" + isVip + ", statusPoints="
				+ statusPoints + ", defenseMonth=" + defenseMonth + ", rake=" + String.format("%.2f",rake) + ", mountlypoints="
				+ monthlypoints + ", yearlypoints=" + yearlypoints + ", frequestPoints=" + frequentPoints + "]";
	}

	
}
