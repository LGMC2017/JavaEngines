package com.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.levels.Player;
import com.levels.PlayerLevel.Level;

public class LevelMainProgram {

	
	public static void main(String[] args) {
		
		List<Player> players = new ArrayList<Player>();
		HashMap<String, Player> playermap = new HashMap<String, Player>();
		
		String[] playernames = new String[] { "Player1", "Player2", "Player3", "Player4", "Player5" };
		
		for(String name : playernames) {
			Player p = new Player();
			String playername = playernames[playermap.size()];
			p.setUserName(playername);
			playermap.put(playername, p);
			players.add(p);
		}
		
		int totalplayers = playermap.size();
		
		String nametofind = "Player3";
		Player playerfound = playermap.get(nametofind);
		
		playerfound.addRake(750.00 / 5.5);
		System.out.println(playerfound);
		
		playerfound.addRake(2250.00 / 5.5);
		System.out.println(playerfound);
		
		playerfound.addRake(500 / 5.5);
		System.out.println(playerfound);
		
		playerfound.addRake(2640 / 5.5);
		System.out.println(playerfound);
		
		
//		for(int i = 0; i < 200; i++) {
//			playerfound.addRake(100.00);
//			System.out.println(playerfound);
//		}
			
	}

}
